
Natvis file to describe types in Visual Studio debugger. 
You can include this in a project file, or install in Visual Studio folder.
